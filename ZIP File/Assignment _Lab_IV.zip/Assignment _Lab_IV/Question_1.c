//Write a program in C to input a string and print it.
#include<stdio.h>
#include<conio.h>
int main()
{
    char line[500];
    printf("Enter your string:\n");
    gets(line);
    getch();
    return 0;
}